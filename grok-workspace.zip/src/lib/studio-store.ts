import { create } from "zustand";

export const COLORWAYS = [
  {
    id: "onyx",
    name: "Onyx",
    body: "#1c1d20",
    cushion: "#141416",
    metal: "#9aa0a8",
    accent: "#2a2c31",
  },
  {
    id: "glacier",
    name: "Glacier",
    body: "#d2dbe3",
    cushion: "#e8eef3",
    metal: "#c5ccd3",
    accent: "#b4c0ca",
  },
  {
    id: "clay",
    name: "Clay",
    body: "#a97858",
    cushion: "#8d6248",
    metal: "#cbb9a6",
    accent: "#8a5c40",
  },
  {
    id: "sage",
    name: "Sage",
    body: "#6d7a70",
    cushion: "#55615a",
    metal: "#b4bbb3",
    accent: "#5a665e",
  },
  {
    id: "ivory",
    name: "Ivory",
    body: "#e7dfd0",
    cushion: "#cfc6b5",
    metal: "#d8d2c6",
    accent: "#d4cbb8",
  },
] as const;

export const FINISHES = [
  {
    id: "matte",
    name: "Matte",
    roughness: 0.78,
    metalness: 0.06,
    clearcoat: 0.04,
    clearcoatRoughness: 0.62,
    sheen: 0.38,
  },
  {
    id: "satin",
    name: "Satin",
    roughness: 0.42,
    metalness: 0.18,
    clearcoat: 0.28,
    clearcoatRoughness: 0.34,
    sheen: 0.2,
  },
  {
    id: "gloss",
    name: "Gloss",
    roughness: 0.12,
    metalness: 0.12,
    clearcoat: 1,
    clearcoatRoughness: 0.07,
    sheen: 0.04,
  },
  {
    id: "metal",
    name: "Metal",
    roughness: 0.22,
    metalness: 0.95,
    clearcoat: 0.55,
    clearcoatRoughness: 0.18,
    sheen: 0,
  },
] as const;

export const LIGHT_PRESETS = [
  { id: "studio", name: "Studio", key: 68, warmth: 38, env: 62 },
  { id: "gallery", name: "Gallery", key: 48, warmth: 18, env: 82 },
  { id: "night", name: "Night", key: 88, warmth: 26, env: 26 },
  { id: "dawn", name: "Dawn", key: 58, warmth: 78, env: 48 },
] as const;

export const VIEWS = [
  {
    id: "hero",
    name: "Hero",
    position: [1.82, 0.66, 2.32] as const,
    target: [0, 0.2, 0] as const,
  },
  {
    id: "profile",
    name: "Profile",
    position: [2.72, 0.32, 0.12] as const,
    target: [0, 0.14, 0] as const,
  },
  {
    id: "detail",
    name: "Detail",
    position: [1.28, 0.12, 1.08] as const,
    target: [0.82, 0.02, 0] as const,
  },
] as const;

export type ColorwayId = (typeof COLORWAYS)[number]["id"];
export type FinishId = (typeof FINISHES)[number]["id"];
export type LightPresetId = (typeof LIGHT_PRESETS)[number]["id"];
export type ViewId = (typeof VIEWS)[number]["id"];

export function getColorway(id: ColorwayId) {
  return COLORWAYS.find((item) => item.id === id) ?? COLORWAYS[0];
}

export function getFinish(id: FinishId) {
  return FINISHES.find((item) => item.id === id) ?? FINISHES[1];
}

export function getLightPreset(id: LightPresetId) {
  return LIGHT_PRESETS.find((item) => item.id === id) ?? LIGHT_PRESETS[0];
}

export function getView(id: ViewId) {
  return VIEWS.find((item) => item.id === id) ?? VIEWS[0];
}

type StudioState = {
  colorway: ColorwayId;
  finish: FinishId;
  autoRotate: boolean;
  lightPreset: LightPresetId;
  keyIntensity: number;
  warmth: number;
  envIntensity: number;
  viewId: ViewId;
  cameraNonce: number;
  zoomTick: number;
  zoomDelta: number;
  lightsOpen: boolean;
  studioReady: boolean;
  hintVisible: boolean;
  bagCount: number;
  setColorway: (id: ColorwayId) => void;
  setFinish: (id: FinishId) => void;
  setAutoRotate: (value: boolean) => void;
  setLightPreset: (id: LightPresetId) => void;
  setKeyIntensity: (value: number) => void;
  setWarmth: (value: number) => void;
  setEnvIntensity: (value: number) => void;
  setView: (id: ViewId) => void;
  cycleView: () => void;
  nudgeZoom: (delta: number) => void;
  resetCamera: () => void;
  setLightsOpen: (value: boolean) => void;
  toggleLightsOpen: () => void;
  setStudioReady: (value: boolean) => void;
  dismissHint: () => void;
  addToBag: () => void;
};

export const useStudio = create<StudioState>((set, get) => ({
  colorway: "onyx",
  finish: "satin",
  autoRotate: true,
  lightPreset: "studio",
  keyIntensity: 68,
  warmth: 38,
  envIntensity: 62,
  viewId: "hero",
  cameraNonce: 0,
  zoomTick: 0,
  zoomDelta: 0,
  lightsOpen: false,
  studioReady: false,
  hintVisible: true,
  bagCount: 0,
  setColorway: (colorway) => set({ colorway }),
  setFinish: (finish) => set({ finish }),
  setAutoRotate: (autoRotate) => set({ autoRotate }),
  setLightPreset: (lightPreset) => {
    const preset = getLightPreset(lightPreset);
    set({
      lightPreset,
      keyIntensity: preset.key,
      warmth: preset.warmth,
      envIntensity: preset.env,
    });
  },
  setKeyIntensity: (keyIntensity) => set({ keyIntensity }),
  setWarmth: (warmth) => set({ warmth }),
  setEnvIntensity: (envIntensity) => set({ envIntensity }),
  setView: (viewId) =>
    set({ viewId, cameraNonce: get().cameraNonce + 1 }),
  cycleView: () => {
    const index = VIEWS.findIndex((item) => item.id === get().viewId);
    const next = VIEWS[(index + 1) % VIEWS.length] ?? VIEWS[0];
    set({ viewId: next.id, cameraNonce: get().cameraNonce + 1 });
  },
  nudgeZoom: (delta) =>
    set({ zoomTick: get().zoomTick + 1, zoomDelta: delta }),
  resetCamera: () =>
    set({ viewId: "hero", cameraNonce: get().cameraNonce + 1 }),
  setLightsOpen: (lightsOpen) => set({ lightsOpen }),
  toggleLightsOpen: () => set({ lightsOpen: !get().lightsOpen }),
  setStudioReady: (studioReady) => set({ studioReady }),
  dismissHint: () => set({ hintVisible: false }),
  addToBag: () => set({ bagCount: get().bagCount + 1 }),
}));
