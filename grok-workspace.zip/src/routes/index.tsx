import { createFileRoute } from "@tanstack/react-router";
import { ProductViewer } from "@/components/product-viewer";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <ProductViewer />;
}
