import { useEffect, useState, type ComponentProps } from "react";
import { toast, Toaster } from "sonner";
import {
  Camera,
  Pause,
  Play,
  RotateCcw,
  ShoppingBag,
  Sun,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ProductStudio } from "@/components/studio/product-studio";
import { cn } from "@/lib/utils";
import {
  COLORWAYS,
  FINISHES,
  LIGHT_PRESETS,
  getColorway,
  getFinish,
  getView,
  useStudio,
  type ColorwayId,
  type LightPresetId,
} from "@/lib/studio-store";

function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

function useDesktop() {
  const [desktop, setDesktop] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const apply = () => setDesktop(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return desktop;
}

function StudioCanvas() {
  const mounted = useMounted();
  if (!mounted) return <div className="h-full w-full bg-background" />;
  return <ProductStudio />;
}

function ToolButton({
  label,
  children,
  className,
  ...props
}: ComponentProps<typeof Button> & { label: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="subtle"
          size="icon"
          aria-label={label}
          className={cn("shadow-[var(--shadow-border)]", className)}
          {...props}
        >
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="left">{label}</TooltipContent>
    </Tooltip>
  );
}

function Header() {
  const bagCount = useStudio((s) => s.bagCount);
  return (
    <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-4 p-4 sm:p-6">
      <div className="stagger-in pointer-events-auto">
        <p className="font-display text-3xl leading-none font-medium tracking-tight italic sm:text-4xl">
          Aura
        </p>
        <p className="mt-1 text-xs tracking-widest text-muted-foreground uppercase">
          Studio
        </p>
      </div>
      {bagCount > 0 ? (
        <div className="stagger-in pointer-events-auto">
          <span className="rounded-full bg-card px-3 py-2 text-xs tabular-nums text-muted-foreground shadow-[var(--shadow-border)]">
            Bag {bagCount}
          </span>
        </div>
      ) : null}
    </header>
  );
}

function ProductCopy() {
  return (
    <div className="pointer-events-none absolute top-24 left-4 z-30 max-w-56 sm:top-28 sm:left-6 sm:max-w-xs">
      <div className="stagger-in">
        <p className="text-xs tracking-widest text-muted-foreground uppercase">
          Aura One
        </p>
        <h1 className="font-display mt-2 text-3xl leading-none font-medium tracking-tight sm:text-5xl">
          Quiet sound, sculpted.
        </h1>
        <p className="mt-3 hidden text-sm leading-relaxed text-muted-foreground sm:block">
          Over-ear wireless in five colorways. Drag to orbit, scroll to zoom.
        </p>
        <p className="mt-3 hidden text-xs tracking-wide text-subtle sm:block">
          40 mm drivers · 40-hour charge · Adaptive quiet
        </p>
      </div>
    </div>
  );
}

function VariantBar() {
  const colorway = useStudio((s) => s.colorway);
  const finish = useStudio((s) => s.finish);
  const setColorway = useStudio((s) => s.setColorway);
  const setFinish = useStudio((s) => s.setFinish);
  const addToBag = useStudio((s) => s.addToBag);
  const activeColor = getColorway(colorway);
  const activeFinish = getFinish(finish);

  const handleBag = () => {
    addToBag();
    toast.success("Added to bag", {
      description: `${activeColor.name} · ${activeFinish.name}`,
    });
  };

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 p-4 sm:p-6">
      <div className="pointer-events-auto mx-auto flex max-w-5xl flex-col gap-3 rounded-2xl bg-card/80 p-3 shadow-[var(--shadow-float)] backdrop-blur-md sm:flex-row sm:items-end sm:gap-6 sm:p-4">
        <div className="min-w-0 flex-1">
          <p className="text-xs text-muted-foreground">Colorway</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {COLORWAYS.map((item) => {
              const selected = item.id === colorway;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-testid={`color-${item.id}`}
                  aria-label={item.name}
                  aria-pressed={selected}
                  onClick={() => setColorway(item.id)}
                  className={cn(
                    "press-scale relative size-11 rounded-full",
                    selected
                      ? "ring-2 ring-primary ring-offset-2 ring-offset-background"
                      : "shadow-[var(--shadow-border)]",
                  )}
                  style={{ backgroundColor: item.body }}
                />
              );
            })}
            <span className="ml-1 text-sm text-foreground">
              {activeColor.name}
            </span>
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs text-muted-foreground">Finish</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {FINISHES.map((item) => {
              const selected = item.id === finish;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-testid={`finish-${item.id}`}
                  aria-pressed={selected}
                  onClick={() => setFinish(item.id)}
                  className={cn(
                    "press-scale h-11 rounded-lg px-3.5 text-sm font-medium",
                    selected
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-foreground hover:bg-muted/80",
                  )}
                >
                  {item.name}
                </button>
              );
            })}
          </div>
        </div>
        <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
          <div className="sm:text-right">
            <p className="text-xs text-muted-foreground">In stock</p>
            <p className="font-display text-3xl leading-none tracking-tight">
              <span className="text-lg text-muted-foreground">$</span>
              <span className="tabular-nums">429</span>
            </p>
          </div>
          <Button
            data-testid="add-to-bag"
            onClick={handleBag}
            className="min-w-36 rounded-lg"
          >
            <ShoppingBag />
            Add to bag
          </Button>
        </div>
      </div>
    </div>
  );
}

function StudioDock() {
  const autoRotate = useStudio((s) => s.autoRotate);
  const setAutoRotate = useStudio((s) => s.setAutoRotate);
  const resetCamera = useStudio((s) => s.resetCamera);
  const nudgeZoom = useStudio((s) => s.nudgeZoom);
  const cycleView = useStudio((s) => s.cycleView);
  const viewId = useStudio((s) => s.viewId);
  const toggleLightsOpen = useStudio((s) => s.toggleLightsOpen);
  const lightsOpen = useStudio((s) => s.lightsOpen);
  const view = getView(viewId);

  return (
    <div className="pointer-events-none absolute top-24 right-4 z-40 flex flex-col items-end gap-2 sm:top-28 sm:right-6">
      <div className="pointer-events-auto flex flex-col gap-2">
        <ToolButton
          label="Reset camera"
          data-testid="reset-camera"
          onClick={resetCamera}
        >
          <RotateCcw />
        </ToolButton>
        <ToolButton
          label={`View: ${view.name}`}
          data-testid="cycle-view"
          onClick={cycleView}
        >
          <Camera />
        </ToolButton>
        <ToolButton
          label={autoRotate ? "Stop auto-rotate" : "Auto-rotate"}
          data-testid="auto-rotate"
          onClick={() => setAutoRotate(!autoRotate)}
          aria-pressed={autoRotate}
        >
          {autoRotate ? <Pause /> : <Play />}
        </ToolButton>
        <ToolButton
          label="Zoom in"
          data-testid="zoom-in"
          onClick={() => nudgeZoom(12)}
        >
          <ZoomIn />
        </ToolButton>
        <ToolButton
          label="Zoom out"
          data-testid="zoom-out"
          onClick={() => nudgeZoom(-12)}
        >
          <ZoomOut />
        </ToolButton>
        <ToolButton
          label="Lighting"
          data-testid="toggle-lights"
          onClick={toggleLightsOpen}
          aria-pressed={lightsOpen}
          className={cn(
            "lg:hidden",
            lightsOpen && "bg-primary text-primary-foreground",
          )}
        >
          <Sun />
        </ToolButton>
      </div>
    </div>
  );
}

function LightingPanel() {
  const mounted = useMounted();
  const desktop = useDesktop();
  const lightsOpen = useStudio((s) => s.lightsOpen);
  const preset = useStudio((s) => s.lightPreset);
  const setLightPreset = useStudio((s) => s.setLightPreset);
  const keyIntensity = useStudio((s) => s.keyIntensity);
  const warmth = useStudio((s) => s.warmth);
  const envIntensity = useStudio((s) => s.envIntensity);
  const setKeyIntensity = useStudio((s) => s.setKeyIntensity);
  const setWarmth = useStudio((s) => s.setWarmth);
  const setEnvIntensity = useStudio((s) => s.setEnvIntensity);

  if (!mounted || (!desktop && !lightsOpen)) return null;

  return (
    <aside
      data-open={lightsOpen || desktop}
      className="chrome-motion pointer-events-auto absolute z-30 w-56 max-lg:inset-x-4 max-lg:bottom-40 max-lg:w-auto lg:top-24 lg:right-20"
    >
      <div className="rounded-2xl bg-card/85 p-3 shadow-[var(--shadow-float)] backdrop-blur-md">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium">Studio light</p>
            <p className="text-xs text-muted-foreground">Shape the room</p>
          </div>
          <Sun className="size-4 text-muted-foreground" />
        </div>
        <div className="mt-3 grid grid-cols-4 gap-1.5 lg:grid-cols-2">
          {LIGHT_PRESETS.map((item) => {
            const selected = item.id === preset;
            return (
              <button
                key={item.id}
                type="button"
                data-testid={`preset-${item.id}`}
                aria-pressed={selected}
                onClick={() => setLightPreset(item.id as LightPresetId)}
                className={cn(
                  "press-scale h-9 rounded-md text-sm font-medium",
                  selected
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground hover:bg-muted/80",
                )}
              >
                {item.name}
              </button>
            );
          })}
        </div>
        <Separator className="my-3" />
        <div className="grid gap-1">
          <Slider
            label="Key light"
            value={keyIntensity}
            onValueChange={setKeyIntensity}
            className="h-8"
          />
          <Slider
            label="Warmth"
            value={warmth}
            onValueChange={setWarmth}
            className="h-8"
          />
          <Slider
            label="Environment"
            value={envIntensity}
            onValueChange={setEnvIntensity}
            className="h-8"
          />
        </div>
        <div className="hidden lg:block">
          <Separator className="my-3" />
          <label className="flex h-9 items-center justify-between gap-3">
            <span className="text-sm">Auto-rotate</span>
            <Switch
              checked={autoRotate}
              onCheckedChange={setAutoRotate}
              aria-label="Auto-rotate"
            />
          </label>
        </div>
      </div>
    </aside>
  );
}

function Hint() {
  const visible = useStudio((s) => s.hintVisible);
  return (
    <p
      className={cn(
        "chrome-motion pointer-events-none absolute bottom-44 left-1/2 z-20 -translate-x-1/2 text-center text-xs text-muted-foreground sm:bottom-40",
        visible ? "opacity-100" : "opacity-0",
      )}
    >
      Drag to orbit · pinch or scroll to zoom
    </p>
  );
}

function LoadingVeil() {
  const ready = useStudio((s) => s.studioReady);
  return (
    <div
      className={cn(
        "chrome-motion pointer-events-none absolute inset-0 z-20 grid place-items-center bg-background",
        ready ? "opacity-0" : "opacity-100",
      )}
      aria-hidden={ready}
    >
      <p className="font-display text-4xl italic">Aura</p>
    </div>
  );
}

export function ProductViewer() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => {
      if (reduce.matches) useStudio.getState().setAutoRotate(false);
    };
    apply();
    reduce.addEventListener("change", apply);

    const onKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement
      ) {
        return;
      }
      const state = useStudio.getState();
      if (event.key === "r" || event.key === "R") {
        state.resetCamera();
      }
      if (event.key === " ") {
        event.preventDefault();
        state.setAutoRotate(!state.autoRotate);
      }
      if (event.key === "v" || event.key === "V") {
        state.cycleView();
      }
      if (event.key === "f" || event.key === "F") {
        const index = FINISHES.findIndex((item) => item.id === state.finish);
        const next = FINISHES[(index + 1) % FINISHES.length];
        if (next) state.setFinish(next.id);
      }
      if (event.key >= "1" && event.key <= "5") {
        const next = COLORWAYS[Number(event.key) - 1];
        if (next) state.setColorway(next.id as ColorwayId);
      }
    };
    window.addEventListener("keydown", onKey);
    const hintTimer = window.setTimeout(() => {
      useStudio.getState().dismissHint();
    }, 5200);
    return () => {
      reduce.removeEventListener("change", apply);
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(hintTimer);
    };
  }, []);

  return (
    <TooltipProvider>
      <main className="relative h-dvh overflow-hidden bg-background text-foreground select-none">
        <div className="absolute inset-0 z-0">
          <StudioCanvas />
        </div>
        <div className="studio-vignette pointer-events-none absolute inset-0 z-10" />
        <LoadingVeil />
        <Header />
        <ProductCopy />
        <StudioDock />
        <LightingPanel />
        <Hint />
        <VariantBar />
      </main>
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          classNames: {
            toast: "bg-card text-foreground border-border",
          },
        }}
      />
    </TooltipProvider>
  );
}
