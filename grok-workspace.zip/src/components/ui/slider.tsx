import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";

type SliderProps = Omit<
  React.ComponentProps<typeof SliderPrimitive.Root>,
  "value" | "onValueChange"
> & {
  value: number;
  onValueChange: (value: number) => void;
  label?: string;
  valueLabel?: string;
};

function Slider({
  className,
  value,
  onValueChange,
  label,
  valueLabel,
  min = 0,
  max = 100,
  step = 1,
  ...props
}: SliderProps) {
  return (
    <div className="grid gap-2">
      {label ? (
        <div className="flex items-center justify-between gap-3 text-xs">
          <label className="font-medium text-muted-foreground">{label}</label>
          <span className="tabular-nums text-foreground">
            {valueLabel ?? value}
          </span>
        </div>
      ) : null}
      <SliderPrimitive.Root
        className={cn(
          "relative flex h-11 w-full touch-none items-center select-none",
          className,
        )}
        value={[value]}
        min={min}
        max={max}
        step={step}
        onValueChange={(next) => onValueChange(next[0] ?? value)}
        {...props}
      >
        <SliderPrimitive.Track className="relative h-1 w-full grow overflow-hidden rounded-full bg-muted">
          <SliderPrimitive.Range className="absolute h-full bg-primary" />
        </SliderPrimitive.Track>
        <SliderPrimitive.Thumb className="block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-ring" />
      </SliderPrimitive.Root>
    </div>
  );
}

export { Slider };
