import { memo, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { Scene } from "@/components/studio/scene";
import { useStudio } from "@/lib/studio-store";

function ReadySignal() {
  useEffect(() => {
    useStudio.getState().setStudioReady(true);
  }, []);
  return null;
}

export const ProductStudio = memo(function ProductStudio() {
  return (
    <Canvas
      className="studio-canvas h-full w-full"
      camera={{ position: [1.82, 0.66, 2.32], fov: 30, near: 0.1, far: 40 }}
      dpr={[1, 1.75]}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.06,
      }}
      onCreated={({ gl }) => {
        gl.setClearColor(0x000000, 0);
        useStudio.getState().setStudioReady(true);
      }}
      onPointerDown={() => useStudio.getState().dismissHint()}
      onDoubleClick={() => useStudio.getState().resetCamera()}
    >
      <ReadySignal />
      <Scene />
    </Canvas>
  );
});
