import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { RoundedBox } from "@react-three/drei";
import * as THREE from "three";
import {
  getColorway,
  getFinish,
  useStudio,
  type ColorwayId,
  type FinishId,
} from "@/lib/studio-store";

function makeGrilleMap() {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.fillStyle = "#0c0c0e";
  ctx.fillRect(0, 0, size, size);
  const cx = size / 2;
  const cy = size / 2;
  for (let ring = 5; ring <= 18; ring += 2) {
    const count = ring * 7;
    const rad = (ring / 18) * 0.44 * size;
    for (let i = 0; i < count; i += 1) {
      const a = (i / count) * Math.PI * 2 + ring * 0.04;
      ctx.fillStyle = ring % 4 === 1 ? "#6d6d76" : "#3a3a42";
      ctx.beginPath();
      ctx.arc(
        cx + Math.cos(a) * rad,
        cy + Math.sin(a) * rad,
        1.65,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

function makeLeatherMap() {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  const image = ctx.createImageData(size, size);
  for (let i = 0; i < image.data.length; i += 4) {
    const n = 148 + Math.random() * 78;
    image.data[i] = n;
    image.data[i + 1] = n;
    image.data[i + 2] = n;
    image.data[i + 3] = 255;
  }
  ctx.putImageData(image, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2.4, 2.4);
  tex.needsUpdate = true;
  return tex;
}

const cupPoints = [
  [0.01, 0.138],
  [0.152, 0.138],
  [0.196, 0.128],
  [0.23, 0.1],
  [0.25, 0.052],
  [0.256, 0.0],
  [0.248, -0.04],
  [0.226, -0.076],
  [0.168, -0.096],
  [0.068, -0.104],
  [0.0, -0.104],
].map(([x, y]) => new THREE.Vector2(x, y));

function Headband({
  canopy,
  cushion,
}: {
  canopy: THREE.MeshPhysicalMaterial;
  cushion: THREE.MeshPhysicalMaterial;
}) {
  const outer = useMemo(
    () =>
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.8, 0.44, 0),
        new THREE.Vector3(-0.68, 0.84, 0),
        new THREE.Vector3(-0.34, 1.1, 0),
        new THREE.Vector3(0, 1.18, 0),
        new THREE.Vector3(0.34, 1.1, 0),
        new THREE.Vector3(0.68, 0.84, 0),
        new THREE.Vector3(0.8, 0.44, 0),
      ]),
    [],
  );
  const inner = useMemo(
    () =>
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.74, 0.42, 0),
        new THREE.Vector3(-0.62, 0.8, 0),
        new THREE.Vector3(-0.32, 1.04, 0),
        new THREE.Vector3(0, 1.1, 0),
        new THREE.Vector3(0.32, 1.04, 0),
        new THREE.Vector3(0.62, 0.8, 0),
        new THREE.Vector3(0.74, 0.42, 0),
      ]),
    [],
  );

  return (
    <group>
      <mesh material={canopy} scale={[1, 1, 0.36]}>
        <tubeGeometry args={[outer, 80, 0.068, 18, false]} />
      </mesh>
      <mesh material={cushion} scale={[1, 1, 0.7]}>
        <tubeGeometry args={[inner, 64, 0.036, 14, false]} />
      </mesh>
    </group>
  );
}

function SliderRail({
  side,
  metal,
}: {
  side: 1 | -1;
  metal: THREE.MeshPhysicalMaterial;
}) {
  return (
    <group>
      <mesh
        material={metal}
        position={[side * 0.86, 0.36, 0]}
        rotation={[0, 0, side * 0.52]}
      >
        <cylinderGeometry args={[0.013, 0.015, 0.3, 12]} />
      </mesh>
      <mesh material={metal} position={[side * 0.8, 0.48, 0]}>
        <sphereGeometry args={[0.028, 16, 16]} />
      </mesh>
      <RoundedBox
        args={[0.046, 0.42, 0.024]}
        radius={0.01}
        smoothness={4}
        position={[side * 0.94, 0.3, 0]}
        rotation={[0, 0, side * 0.18]}
        material={metal}
      />
    </group>
  );
}

function EarCup({
  side,
  body,
  cushion,
  metal,
  dark,
  grille,
}: {
  side: 1 | -1;
  body: THREE.MeshPhysicalMaterial;
  cushion: THREE.MeshPhysicalMaterial;
  metal: THREE.MeshPhysicalMaterial;
  dark: THREE.MeshPhysicalMaterial;
  grille: THREE.MeshPhysicalMaterial;
}) {
  return (
    <group
      position={[side * 1.08, 0.02, 0]}
      rotation={[0.06, side * -Math.PI * 0.5, side * 0.1]}
    >
      <mesh material={body} rotation={[Math.PI / 2, 0, 0]}>
        <latheGeometry args={[cupPoints, 48]} />
      </mesh>
      <mesh
        material={metal}
        position={[0, 0, 0.012]}
        rotation={[Math.PI / 2, 0, 0]}
      >
        <torusGeometry args={[0.248, 0.01, 10, 48]} />
      </mesh>
      <mesh
        material={cushion}
        position={[0, 0, 0.1]}
        rotation={[Math.PI / 2, 0, 0]}
      >
        <torusGeometry args={[0.2, 0.056, 18, 48]} />
      </mesh>
      <mesh
        material={dark}
        position={[0, 0, 0.148]}
        rotation={[Math.PI / 2, 0, 0]}
      >
        <torusGeometry args={[0.168, 0.01, 8, 32]} />
      </mesh>
      <mesh material={dark} position={[0, 0, 0.055]}>
        <circleGeometry args={[0.162, 32]} />
      </mesh>
      <mesh material={grille} position={[0, 0, 0.062]}>
        <circleGeometry args={[0.146, 32]} />
      </mesh>
      <mesh
        material={metal}
        rotation={[Math.PI / 2, Math.PI, 0]}
        position={[0, 0.02, -0.018]}
      >
        <torusGeometry args={[0.34, 0.015, 8, 28, Math.PI]} />
      </mesh>
      <mesh material={metal} position={[0, 0.36, -0.018]}>
        <sphereGeometry args={[0.026, 16, 16]} />
      </mesh>
      <mesh material={metal} position={[0, 0, -0.108]} rotation={[Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.078, 28]} />
      </mesh>
      <mesh material={metal} position={[0, 0, -0.11]} rotation={[0, 0, 0.4]}>
        <torusGeometry args={[0.042, 0.006, 8, 24, Math.PI * 1.45]} />
      </mesh>
      {side === 1 ? (
        <group position={[0.02, 0.2, 0.02]} rotation={[0, 0, Math.PI / 2]}>
          <mesh material={metal}>
            <cylinderGeometry args={[0.02, 0.02, 0.046, 16]} />
          </mesh>
          <mesh material={dark} position={[0, 0.026, 0]}>
            <cylinderGeometry args={[0.014, 0.014, 0.01, 16]} />
          </mesh>
        </group>
      ) : (
        <mesh position={[0.12, -0.2, 0.04]}>
          <sphereGeometry args={[0.011, 12, 12]} />
          <meshStandardMaterial
            color="#efe6d4"
            emissive="#d9c8a4"
            emissiveIntensity={1.35}
          />
        </mesh>
      )}
    </group>
  );
}

function useProductMaterials(colorwayId: ColorwayId, finishId: FinishId) {
  const leatherMap = useMemo(() => makeLeatherMap(), []);
  const grilleMap = useMemo(() => makeGrilleMap(), []);

  const materials = useMemo(() => {
    const body = new THREE.MeshPhysicalMaterial({
      color: "#1c1d20",
      roughness: 0.42,
      metalness: 0.18,
      clearcoat: 0.28,
      clearcoatRoughness: 0.34,
      sheen: 0.2,
      sheenRoughness: 0.7,
      envMapIntensity: 1.1,
    });
    const cushion = new THREE.MeshPhysicalMaterial({
      color: "#141416",
      roughness: 0.78,
      metalness: 0.02,
      sheen: 0.85,
      sheenColor: new THREE.Color("#2a2420"),
      sheenRoughness: 0.42,
      roughnessMap: leatherMap ?? undefined,
    });
    const metal = new THREE.MeshPhysicalMaterial({
      color: "#9aa0a8",
      roughness: 0.22,
      metalness: 1,
      clearcoat: 0.5,
      clearcoatRoughness: 0.16,
      envMapIntensity: 1.35,
    });
    const dark = new THREE.MeshPhysicalMaterial({
      color: "#0e0e10",
      roughness: 0.9,
      metalness: 0.08,
    });
    const grille = new THREE.MeshPhysicalMaterial({
      map: grilleMap ?? undefined,
      roughness: 0.52,
      metalness: 0.4,
      color: "#c8c8cc",
    });
    return { body, cushion, metal, dark, grille };
  }, [grilleMap, leatherMap]);

  const bodyColor = useRef(new THREE.Color("#1c1d20"));
  const cushionColor = useRef(new THREE.Color("#141416"));
  const metalColor = useRef(new THREE.Color("#9aa0a8"));
  const sheenColor = useRef(new THREE.Color("#2a2420"));
  const targetBody = useRef(new THREE.Color());
  const targetCushion = useRef(new THREE.Color());
  const targetMetal = useRef(new THREE.Color());
  const targetSheen = useRef(new THREE.Color());

  useFrame((_, delta) => {
    const t = 1 - Math.exp(-Math.min(delta, 0.1) * 9);
    const colorway = getColorway(colorwayId);
    const finish = getFinish(finishId);
    targetBody.current.set(colorway.body);
    targetCushion.current.set(colorway.cushion);
    targetMetal.current.set(colorway.metal);
    targetSheen.current.set(colorway.cushion).multiplyScalar(1.15);
    bodyColor.current.lerp(targetBody.current, t);
    cushionColor.current.lerp(targetCushion.current, t);
    metalColor.current.lerp(targetMetal.current, t);
    sheenColor.current.lerp(targetSheen.current, t);
    materials.body.color.copy(bodyColor.current);
    materials.body.roughness = THREE.MathUtils.lerp(
      materials.body.roughness,
      finish.roughness,
      t,
    );
    materials.body.metalness = THREE.MathUtils.lerp(
      materials.body.metalness,
      finish.metalness,
      t,
    );
    materials.body.clearcoat = THREE.MathUtils.lerp(
      materials.body.clearcoat,
      finish.clearcoat,
      t,
    );
    materials.body.clearcoatRoughness = THREE.MathUtils.lerp(
      materials.body.clearcoatRoughness,
      finish.clearcoatRoughness,
      t,
    );
    materials.body.sheen = THREE.MathUtils.lerp(
      materials.body.sheen,
      finish.sheen,
      t,
    );
    materials.cushion.color.copy(cushionColor.current);
    materials.cushion.sheenColor.copy(sheenColor.current);
    materials.metal.color.copy(metalColor.current);
    materials.metal.roughness = THREE.MathUtils.lerp(
      materials.metal.roughness,
      finish.id === "matte" ? 0.38 : 0.2,
      t,
    );
  });

  useEffect(() => {
    return () => {
      leatherMap?.dispose();
      grilleMap?.dispose();
      Object.values(materials).forEach((mat) => mat.dispose());
    };
  }, [grilleMap, leatherMap, materials]);

  return materials;
}

export function Headphones() {
  const colorwayId = useStudio((s) => s.colorway);
  const finishId = useStudio((s) => s.finish);
  const materials = useProductMaterials(colorwayId, finishId);

  return (
    <group position={[0, 0.08, 0]}>
      <Headband canopy={materials.metal} cushion={materials.cushion} />
      {([-1, 1] as const).map((side) => (
        <group key={side}>
          <SliderRail side={side} metal={materials.metal} />
          <EarCup
            side={side}
            body={materials.body}
            cushion={materials.cushion}
            metal={materials.metal}
            dark={materials.dark}
            grille={materials.grille}
          />
        </group>
      ))}
    </group>
  );
}
