import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Lightformer,
  MeshReflectorMaterial,
  OrbitControls,
} from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import * as THREE from "three";
import { Headphones } from "@/components/studio/headphones";
import { getView, useStudio } from "@/lib/studio-store";

const MIN_DIST = 1.52;
const MAX_DIST = 4.65;

export function CameraRig() {
  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const cameraNonce = useStudio((s) => s.cameraNonce);
  const viewId = useStudio((s) => s.viewId);
  const autoRotate = useStudio((s) => s.autoRotate);
  const zoomTick = useStudio((s) => s.zoomTick);
  const zoomDelta = useStudio((s) => s.zoomDelta);
  const { camera } = useThree();

  const startPos = useMemo(() => new THREE.Vector3(), []);
  const endPos = useMemo(() => new THREE.Vector3(), []);
  const startTarget = useMemo(() => new THREE.Vector3(), []);
  const endTarget = useMemo(() => new THREE.Vector3(), []);
  const dir = useMemo(() => new THREE.Vector3(), []);
  const anim = useRef({ active: false, t: 0 });

  useEffect(() => {
    const controls = controlsRef.current;
    if (!controls) return;
    const view = getView(viewId);
    startPos.copy(camera.position);
    endPos.set(view.position[0], view.position[1], view.position[2]);
    startTarget.copy(controls.target);
    endTarget.set(view.target[0], view.target[1], view.target[2]);
    anim.current = { active: true, t: 0 };
  }, [cameraNonce, viewId, camera, startPos, endPos, startTarget, endTarget]);

  useEffect(() => {
    if (zoomTick === 0) return;
    const controls = controlsRef.current;
    if (!controls) return;
    dir.subVectors(camera.position, controls.target);
    const dist = dir.length();
    if (dist < 1e-6) dir.set(2, 0.6, 3);
    else dir.normalize();
    const next = THREE.MathUtils.clamp(
      dist - zoomDelta * 0.026,
      MIN_DIST,
      MAX_DIST,
    );
    camera.position.copy(controls.target).addScaledVector(dir, next);
    endPos.copy(camera.position);
    controls.update();
  }, [zoomTick, zoomDelta, camera, dir, endPos]);

  useFrame((_, delta) => {
    const controls = controlsRef.current;
    if (!controls) return;
    if (anim.current.active) {
      const d = Math.min(delta, 0.1);
      anim.current.t = Math.min(1, anim.current.t + d * 2.6);
      const k = 1 - (1 - anim.current.t) ** 3;
      camera.position.lerpVectors(startPos, endPos, k);
      controls.target.lerpVectors(startTarget, endTarget, k);
      controls.update();
      if (anim.current.t >= 1) anim.current.active = false;
    }
    controls.autoRotate = autoRotate && !anim.current.active;
  });

  return (
    <OrbitControls
      ref={controlsRef}
      makeDefault
      enableDamping
      dampingFactor={0.085}
      autoRotate={autoRotate}
      autoRotateSpeed={0.55}
      minDistance={MIN_DIST}
      maxDistance={MAX_DIST}
      minPolarAngle={Math.PI * 0.2}
      maxPolarAngle={Math.PI * 0.58}
      enablePan={false}
      rotateSpeed={0.68}
      zoomSpeed={0.85}
      touches={{ ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_ROTATE }}
    />
  );
}

function StudioLights() {
  const preset = useStudio((s) => s.lightPreset);
  const keyIntensity = useStudio((s) => s.keyIntensity);
  const warmth = useStudio((s) => s.warmth);
  const envIntensity = useStudio((s) => s.envIntensity);
  const { scene, gl } = useThree();

  const keyColor = useMemo(() => new THREE.Color(), []);
  const fillColor = useMemo(() => new THREE.Color(), []);
  const rimColor = useMemo(() => new THREE.Color(), []);
  const coolKey = useMemo(() => new THREE.Color("#c9d4e4"), []);
  const warmKey = useMemo(() => new THREE.Color("#ffd6ae"), []);
  const coolFill = useMemo(() => new THREE.Color("#8ea0b8"), []);
  const warmFill = useMemo(() => new THREE.Color("#e7c3a4"), []);
  const coolRim = useMemo(() => new THREE.Color("#b7c4d4"), []);
  const warmRim = useMemo(() => new THREE.Color("#f0d2b4"), []);

  const warmthT = warmth / 100;
  keyColor.lerpColors(coolKey, warmKey, warmthT);
  fillColor.lerpColors(coolFill, warmFill, warmthT * 0.7);
  rimColor.lerpColors(coolRim, warmRim, warmthT * 0.45);

  const key = (keyIntensity / 100) * (preset === "night" ? 2.1 : 1.55);
  const fill = (keyIntensity / 100) * (preset === "gallery" ? 0.85 : 0.42);
  const rim = (keyIntensity / 100) * (preset === "night" ? 1.6 : 0.7);
  const hemi = preset === "gallery" ? 0.38 : preset === "night" ? 0.08 : 0.16;
  const topGain = preset === "night" ? 0.45 : preset === "dawn" ? 0.8 : 1.15;
  const backGain = preset === "night" ? 1.6 : 0.9;
  const envKey = `${preset}-${Math.round(warmth / 8)}`;

  useEffect(() => {
    scene.environmentIntensity = (envIntensity / 100) * 1.15;
    gl.toneMappingExposure =
      preset === "night" ? 0.84 : preset === "dawn" ? 1.12 : 1.06;
  }, [envIntensity, scene, gl, preset]);

  return (
    <>
      <hemisphereLight
        color={keyColor}
        groundColor="#121110"
        intensity={hemi}
      />
      <directionalLight
        position={[3.2, 3.4, 2.2]}
        intensity={key}
        color={keyColor}
      />
      <directionalLight
        position={[-3.4, 1.4, 1.6]}
        intensity={fill}
        color={fillColor}
      />
      <directionalLight
        position={[-0.4, 1.8, -3.4]}
        intensity={rim}
        color={rimColor}
      />
      <pointLight
        position={[0.6, 1.1, 1.4]}
        intensity={0.22 * (keyIntensity / 100)}
        color={keyColor}
        distance={5}
      />
      <Environment
        key={envKey}
        resolution={256}
        frames={1}
        environmentIntensity={(envIntensity / 100) * 1.1}
      >
        <Lightformer
          form="rect"
          intensity={3.4 * topGain * (envIntensity / 100)}
          position={[0, 4.2, 0]}
          rotation-x={Math.PI / 2}
          scale={[9, 9, 1]}
          color={preset === "dawn" ? "#f3e0c8" : "#f2f2f4"}
        />
        <Lightformer
          form="rect"
          intensity={1.8 * (envIntensity / 100)}
          position={[4.4, 1.2, 2.2]}
          scale={[3.2, 5, 1]}
          color={keyColor}
        />
        <Lightformer
          form="rect"
          intensity={1.1 * (envIntensity / 100)}
          position={[-4.2, 0.6, 1.6]}
          scale={[2.6, 5.4, 1]}
          color={fillColor}
        />
        <Lightformer
          form="ring"
          intensity={2.2 * backGain * (envIntensity / 100)}
          position={[0.2, 1.4, -3.6]}
          scale={3.2}
          color={rimColor}
        />
      </Environment>
    </>
  );
}

function StudioFloor() {
  const width = useThree((s) => s.size.width);
  const resolution = width < 500 ? 128 : 256;

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.55, 0]}>
        <circleGeometry args={[7.5, 64]} />
        <MeshReflectorMaterial
          blur={[280, 70]}
          resolution={resolution}
          mixBlur={0.85}
          mixStrength={18}
          roughness={0.9}
          metalness={0.42}
          mirror={0.12}
          color="#101012"
        />
      </mesh>
    </group>
  );
}

export function Scene() {
  const dismissHint = useStudio((s) => s.dismissHint);

  return (
    <>
      <CameraRig />
      <StudioLights />
      <Headphones />
      <StudioFloor />
      <ContactShadows
        position={[0, -0.547, 0]}
        opacity={0.48}
        scale={6.5}
        blur={2.8}
        far={1.6}
        color="#000000"
      />
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -0.54, 0]}
        onPointerDown={dismissHint}
      >
        <circleGeometry args={[6, 48]} />
        <meshBasicMaterial transparent opacity={0} />
      </mesh>
    </>
  );
}
