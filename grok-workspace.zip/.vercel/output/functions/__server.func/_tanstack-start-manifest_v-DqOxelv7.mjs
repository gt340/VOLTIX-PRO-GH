//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DqOxelv7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BUFBdoF-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUFBdoF-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Csp0W7i-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
