import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { r as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as MeshReflectorMaterial, c as useFrame, i as RoundedBox, l as useThree, n as ContactShadows, o as OrbitControls, r as Environment, s as Canvas, t as Lightformer } from "../_libs/@react-three/drei+[...].mjs";
import { a as ShoppingBag, c as Pause, i as Sun, l as Camera, n as ZoomOut, o as RotateCcw, s as Play, t as ZoomIn } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { A as MeshPhysicalMaterial, E as MathUtils, H as SRGBColorSpace, Q as Vector3, V as RepeatWrapping, Z as Vector2, f as Color, l as CanvasTexture, q as TOUCH, u as CatmullRomCurve3 } from "../_libs/monogrid__gainmap-js+three.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DkMSI_7C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("press-scale inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/70",
			outline: "shadow-[var(--shadow-border)] bg-transparent text-foreground hover:shadow-[var(--shadow-border-hover)] hover:bg-card",
			ghost: "text-foreground hover:bg-card",
			subtle: "bg-card text-foreground hover:bg-muted"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Slider({ className, value, onValueChange, label, valueLabel, min = 0, max = 100, step = 1, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "font-medium text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-foreground",
				children: valueLabel ?? value
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
			className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
			value: [value],
			min,
			max,
			step,
			onValueChange: (next) => onValueChange(next[0] ?? value),
			...props,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
				className: "relative h-1 w-full grow overflow-hidden rounded-full bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
		})]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-7 w-12 shrink-0 items-center rounded-full bg-muted shadow-[var(--shadow-border)] transition-[background-color,box-shadow] duration-150 ease-out data-[state=checked]:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-40", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-1 rounded-full bg-foreground transition-transform duration-150 ease-out data-[state=checked]:translate-x-6 data-[state=checked]:bg-primary-foreground" })
	});
}
function Separator({ className, orientation = "horizontal" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "separator",
		"aria-orientation": orientation,
		className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className)
	});
}
function TooltipProvider({ delayDuration = 250, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
function Tooltip({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root3, { ...props });
}
function TooltipTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, { ...props });
}
function TooltipContent({ className, sideOffset = 8, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-50 rounded-md bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-[var(--shadow-float)]", className),
		...props
	}) });
}
var COLORWAYS = [
	{
		id: "onyx",
		name: "Onyx",
		body: "#1c1d20",
		cushion: "#141416",
		metal: "#9aa0a8",
		accent: "#2a2c31"
	},
	{
		id: "glacier",
		name: "Glacier",
		body: "#d2dbe3",
		cushion: "#e8eef3",
		metal: "#c5ccd3",
		accent: "#b4c0ca"
	},
	{
		id: "clay",
		name: "Clay",
		body: "#a97858",
		cushion: "#8d6248",
		metal: "#cbb9a6",
		accent: "#8a5c40"
	},
	{
		id: "sage",
		name: "Sage",
		body: "#6d7a70",
		cushion: "#55615a",
		metal: "#b4bbb3",
		accent: "#5a665e"
	},
	{
		id: "ivory",
		name: "Ivory",
		body: "#e7dfd0",
		cushion: "#cfc6b5",
		metal: "#d8d2c6",
		accent: "#d4cbb8"
	}
];
var FINISHES = [
	{
		id: "matte",
		name: "Matte",
		roughness: .78,
		metalness: .06,
		clearcoat: .04,
		clearcoatRoughness: .62,
		sheen: .38
	},
	{
		id: "satin",
		name: "Satin",
		roughness: .42,
		metalness: .18,
		clearcoat: .28,
		clearcoatRoughness: .34,
		sheen: .2
	},
	{
		id: "gloss",
		name: "Gloss",
		roughness: .12,
		metalness: .12,
		clearcoat: 1,
		clearcoatRoughness: .07,
		sheen: .04
	},
	{
		id: "metal",
		name: "Metal",
		roughness: .22,
		metalness: .95,
		clearcoat: .55,
		clearcoatRoughness: .18,
		sheen: 0
	}
];
var LIGHT_PRESETS = [
	{
		id: "studio",
		name: "Studio",
		key: 68,
		warmth: 38,
		env: 62
	},
	{
		id: "gallery",
		name: "Gallery",
		key: 48,
		warmth: 18,
		env: 82
	},
	{
		id: "night",
		name: "Night",
		key: 88,
		warmth: 26,
		env: 26
	},
	{
		id: "dawn",
		name: "Dawn",
		key: 58,
		warmth: 78,
		env: 48
	}
];
var VIEWS = [
	{
		id: "hero",
		name: "Hero",
		position: [
			1.92,
			.7,
			2.4
		],
		target: [
			0,
			.22,
			0
		]
	},
	{
		id: "profile",
		name: "Profile",
		position: [
			2.86,
			.34,
			.14
		],
		target: [
			0,
			.16,
			0
		]
	},
	{
		id: "detail",
		name: "Detail",
		position: [
			1.32,
			.14,
			1.08
		],
		target: [
			.84,
			.02,
			0
		]
	}
];
function getColorway(id) {
	return COLORWAYS.find((item) => item.id === id) ?? COLORWAYS[0];
}
function getFinish(id) {
	return FINISHES.find((item) => item.id === id) ?? FINISHES[1];
}
function getLightPreset(id) {
	return LIGHT_PRESETS.find((item) => item.id === id) ?? LIGHT_PRESETS[0];
}
function getView(id) {
	return VIEWS.find((item) => item.id === id) ?? VIEWS[0];
}
var useStudio = create((set, get) => ({
	colorway: "onyx",
	finish: "satin",
	autoRotate: true,
	lightPreset: "studio",
	keyIntensity: 68,
	warmth: 38,
	envIntensity: 62,
	viewId: "hero",
	cameraNonce: 0,
	zoomTick: 0,
	zoomDelta: 0,
	lightsOpen: false,
	studioReady: false,
	hintVisible: true,
	bagCount: 0,
	setColorway: (colorway) => set({ colorway }),
	setFinish: (finish) => set({ finish }),
	setAutoRotate: (autoRotate) => set({ autoRotate }),
	setLightPreset: (lightPreset) => {
		const preset = getLightPreset(lightPreset);
		set({
			lightPreset,
			keyIntensity: preset.key,
			warmth: preset.warmth,
			envIntensity: preset.env
		});
	},
	setKeyIntensity: (keyIntensity) => set({ keyIntensity }),
	setWarmth: (warmth) => set({ warmth }),
	setEnvIntensity: (envIntensity) => set({ envIntensity }),
	setView: (viewId) => set({
		viewId,
		cameraNonce: get().cameraNonce + 1
	}),
	cycleView: () => {
		set({
			viewId: (VIEWS[(VIEWS.findIndex((item) => item.id === get().viewId) + 1) % VIEWS.length] ?? VIEWS[0]).id,
			cameraNonce: get().cameraNonce + 1
		});
	},
	nudgeZoom: (delta) => set({
		zoomTick: get().zoomTick + 1,
		zoomDelta: delta
	}),
	resetCamera: () => set({
		viewId: "hero",
		cameraNonce: get().cameraNonce + 1
	}),
	setLightsOpen: (lightsOpen) => set({ lightsOpen }),
	toggleLightsOpen: () => set({ lightsOpen: !get().lightsOpen }),
	setStudioReady: (studioReady) => set({ studioReady }),
	dismissHint: () => set({ hintVisible: false }),
	addToBag: () => set({ bagCount: get().bagCount + 1 })
}));
function makeGrilleMap() {
	const size = 256;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) return null;
	ctx.fillStyle = "#0c0c0e";
	ctx.fillRect(0, 0, size, size);
	const cx = size / 2;
	const cy = size / 2;
	for (let ring = 5; ring <= 18; ring += 2) {
		const count = ring * 7;
		const rad = ring / 18 * .44 * size;
		for (let i = 0; i < count; i += 1) {
			const a = i / count * Math.PI * 2 + ring * .04;
			ctx.fillStyle = ring % 4 === 1 ? "#6d6d76" : "#3a3a42";
			ctx.beginPath();
			ctx.arc(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad, 1.65, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 8;
	tex.needsUpdate = true;
	return tex;
}
function makeLeatherMap() {
	const size = 256;
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d");
	if (!ctx) return null;
	const image = ctx.createImageData(size, size);
	for (let i = 0; i < image.data.length; i += 4) {
		const n = 148 + Math.random() * 78;
		image.data[i] = n;
		image.data[i + 1] = n;
		image.data[i + 2] = n;
		image.data[i + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
	const tex = new CanvasTexture(canvas);
	tex.wrapS = RepeatWrapping;
	tex.wrapT = RepeatWrapping;
	tex.repeat.set(2.4, 2.4);
	tex.needsUpdate = true;
	return tex;
}
var cupPoints = [
	[.01, .138],
	[.152, .138],
	[.196, .128],
	[.23, .1],
	[.25, .052],
	[.256, 0],
	[.248, -.04],
	[.226, -.076],
	[.168, -.096],
	[.068, -.104],
	[0, -.104]
].map(([x, y]) => new Vector2(x, y));
function Headband({ canopy, cushion }) {
	const outer = (0, import_react.useMemo)(() => new CatmullRomCurve3([
		new Vector3(-.8, .44, 0),
		new Vector3(-.68, .84, 0),
		new Vector3(-.34, 1.1, 0),
		new Vector3(0, 1.18, 0),
		new Vector3(.34, 1.1, 0),
		new Vector3(.68, .84, 0),
		new Vector3(.8, .44, 0)
	]), []);
	const inner = (0, import_react.useMemo)(() => new CatmullRomCurve3([
		new Vector3(-.74, .42, 0),
		new Vector3(-.62, .8, 0),
		new Vector3(-.32, 1.04, 0),
		new Vector3(0, 1.1, 0),
		new Vector3(.32, 1.04, 0),
		new Vector3(.62, .8, 0),
		new Vector3(.74, .42, 0)
	]), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		material: canopy,
		scale: [
			1,
			1,
			.36
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
			outer,
			80,
			.068,
			18,
			false
		] })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
		material: cushion,
		scale: [
			1,
			1,
			.7
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
			inner,
			64,
			.036,
			14,
			false
		] })
	})] });
}
function SliderRail({ side, metal }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			material: metal,
			position: [
				side * .86,
				.36,
				0
			],
			rotation: [
				0,
				0,
				side * .52
			],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.013,
				.015,
				.3,
				12
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			material: metal,
			position: [
				side * .8,
				.48,
				0
			],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.028,
				16,
				16
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundedBox, {
			args: [
				.046,
				.42,
				.024
			],
			radius: .01,
			smoothness: 4,
			position: [
				side * .94,
				.3,
				0
			],
			rotation: [
				0,
				0,
				side * .18
			],
			material: metal
		})
	] });
}
function EarCup({ side, body, cushion, metal, dark, grille }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			side * 1.08,
			.02,
			0
		],
		rotation: [
			.06,
			side * -Math.PI * .5,
			side * .1
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: body,
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("latheGeometry", { args: [cupPoints, 48] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: metal,
				position: [
					0,
					0,
					.012
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.248,
					.01,
					10,
					48
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: cushion,
				position: [
					0,
					0,
					.1
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.2,
					.056,
					18,
					48
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: dark,
				position: [
					0,
					0,
					.148
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.168,
					.01,
					8,
					32
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: dark,
				position: [
					0,
					0,
					.055
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [.162, 32] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: grille,
				position: [
					0,
					0,
					.062
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [.146, 32] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: metal,
				rotation: [
					Math.PI / 2,
					Math.PI,
					0
				],
				position: [
					0,
					.02,
					-.018
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.34,
					.015,
					8,
					28,
					Math.PI
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: metal,
				position: [
					0,
					.36,
					-.018
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.026,
					16,
					16
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: metal,
				position: [
					0,
					0,
					-.108
				],
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [.078, 28] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
				material: metal,
				position: [
					0,
					0,
					-.11
				],
				rotation: [
					0,
					0,
					.4
				],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.042,
					.006,
					8,
					24,
					Math.PI * 1.45
				] })
			}),
			side === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				position: [
					.02,
					.2,
					.02
				],
				rotation: [
					0,
					0,
					Math.PI / 2
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
					material: metal,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.02,
						.02,
						.046,
						16
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
					material: dark,
					position: [
						0,
						.026,
						0
					],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.014,
						.014,
						.01,
						16
					] })
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.12,
					-.2,
					.04
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.011,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#efe6d4",
					emissive: "#d9c8a4",
					emissiveIntensity: 1.35
				})]
			})
		]
	});
}
function useProductMaterials(colorwayId, finishId) {
	const leatherMap = (0, import_react.useMemo)(() => makeLeatherMap(), []);
	const grilleMap = (0, import_react.useMemo)(() => makeGrilleMap(), []);
	const materials = (0, import_react.useMemo)(() => {
		return {
			body: new MeshPhysicalMaterial({
				color: "#1c1d20",
				roughness: .42,
				metalness: .18,
				clearcoat: .28,
				clearcoatRoughness: .34,
				sheen: .2,
				sheenRoughness: .7,
				envMapIntensity: 1.1
			}),
			cushion: new MeshPhysicalMaterial({
				color: "#141416",
				roughness: .78,
				metalness: .02,
				sheen: .85,
				sheenColor: new Color("#2a2420"),
				sheenRoughness: .42,
				roughnessMap: leatherMap ?? void 0
			}),
			metal: new MeshPhysicalMaterial({
				color: "#9aa0a8",
				roughness: .22,
				metalness: 1,
				clearcoat: .5,
				clearcoatRoughness: .16,
				envMapIntensity: 1.35
			}),
			dark: new MeshPhysicalMaterial({
				color: "#0e0e10",
				roughness: .9,
				metalness: .08
			}),
			grille: new MeshPhysicalMaterial({
				map: grilleMap ?? void 0,
				roughness: .52,
				metalness: .4,
				color: "#c8c8cc"
			})
		};
	}, [grilleMap, leatherMap]);
	const bodyColor = (0, import_react.useRef)(new Color("#1c1d20"));
	const cushionColor = (0, import_react.useRef)(new Color("#141416"));
	const metalColor = (0, import_react.useRef)(new Color("#9aa0a8"));
	const sheenColor = (0, import_react.useRef)(new Color("#2a2420"));
	const targetBody = (0, import_react.useRef)(new Color());
	const targetCushion = (0, import_react.useRef)(new Color());
	const targetMetal = (0, import_react.useRef)(new Color());
	const targetSheen = (0, import_react.useRef)(new Color());
	useFrame((_, delta) => {
		const t = 1 - Math.exp(-Math.min(delta, .1) * 9);
		const colorway = getColorway(colorwayId);
		const finish = getFinish(finishId);
		targetBody.current.set(colorway.body);
		targetCushion.current.set(colorway.cushion);
		targetMetal.current.set(colorway.metal);
		targetSheen.current.set(colorway.cushion).multiplyScalar(1.15);
		bodyColor.current.lerp(targetBody.current, t);
		cushionColor.current.lerp(targetCushion.current, t);
		metalColor.current.lerp(targetMetal.current, t);
		sheenColor.current.lerp(targetSheen.current, t);
		materials.body.color.copy(bodyColor.current);
		materials.body.roughness = MathUtils.lerp(materials.body.roughness, finish.roughness, t);
		materials.body.metalness = MathUtils.lerp(materials.body.metalness, finish.metalness, t);
		materials.body.clearcoat = MathUtils.lerp(materials.body.clearcoat, finish.clearcoat, t);
		materials.body.clearcoatRoughness = MathUtils.lerp(materials.body.clearcoatRoughness, finish.clearcoatRoughness, t);
		materials.body.sheen = MathUtils.lerp(materials.body.sheen, finish.sheen, t);
		materials.cushion.color.copy(cushionColor.current);
		materials.cushion.sheenColor.copy(sheenColor.current);
		materials.metal.color.copy(metalColor.current);
		materials.metal.roughness = MathUtils.lerp(materials.metal.roughness, finish.id === "matte" ? .38 : .2, t);
	});
	(0, import_react.useEffect)(() => {
		return () => {
			leatherMap?.dispose();
			grilleMap?.dispose();
			Object.values(materials).forEach((mat) => mat.dispose());
		};
	}, [
		grilleMap,
		leatherMap,
		materials
	]);
	return materials;
}
function Headphones() {
	const materials = useProductMaterials(useStudio((s) => s.colorway), useStudio((s) => s.finish));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			0,
			.08,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headband, {
			canopy: materials.metal,
			cushion: materials.cushion
		}), [-1, 1].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRail, {
			side,
			metal: materials.metal
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EarCup, {
			side,
			body: materials.body,
			cushion: materials.cushion,
			metal: materials.metal,
			dark: materials.dark,
			grille: materials.grille
		})] }, side))]
	});
}
var MIN_DIST = 1.52;
var MAX_DIST = 4.65;
function CameraRig() {
	const controlsRef = (0, import_react.useRef)(null);
	const cameraNonce = useStudio((s) => s.cameraNonce);
	const viewId = useStudio((s) => s.viewId);
	const autoRotate = useStudio((s) => s.autoRotate);
	const zoomTick = useStudio((s) => s.zoomTick);
	const zoomDelta = useStudio((s) => s.zoomDelta);
	const { camera } = useThree();
	const startPos = (0, import_react.useMemo)(() => new Vector3(), []);
	const endPos = (0, import_react.useMemo)(() => new Vector3(), []);
	const startTarget = (0, import_react.useMemo)(() => new Vector3(), []);
	const endTarget = (0, import_react.useMemo)(() => new Vector3(), []);
	const dir = (0, import_react.useMemo)(() => new Vector3(), []);
	const anim = (0, import_react.useRef)({
		active: false,
		t: 0
	});
	(0, import_react.useEffect)(() => {
		const controls = controlsRef.current;
		if (!controls) return;
		const view = getView(viewId);
		startPos.copy(camera.position);
		endPos.set(view.position[0], view.position[1], view.position[2]);
		startTarget.copy(controls.target);
		endTarget.set(view.target[0], view.target[1], view.target[2]);
		anim.current = {
			active: true,
			t: 0
		};
	}, [
		cameraNonce,
		viewId,
		camera,
		startPos,
		endPos,
		startTarget,
		endTarget
	]);
	(0, import_react.useEffect)(() => {
		if (zoomTick === 0) return;
		const controls = controlsRef.current;
		if (!controls) return;
		dir.subVectors(camera.position, controls.target);
		const dist = dir.length();
		if (dist < 1e-6) dir.set(2, .6, 3);
		else dir.normalize();
		const next = MathUtils.clamp(dist - zoomDelta * .026, MIN_DIST, MAX_DIST);
		camera.position.copy(controls.target).addScaledVector(dir, next);
		endPos.copy(camera.position);
		controls.update();
	}, [
		zoomTick,
		zoomDelta,
		camera,
		dir,
		endPos
	]);
	useFrame((_, delta) => {
		const controls = controlsRef.current;
		if (!controls) return;
		if (anim.current.active) {
			const d = Math.min(delta, .1);
			anim.current.t = Math.min(1, anim.current.t + d * 2.6);
			const k = 1 - (1 - anim.current.t) ** 3;
			camera.position.lerpVectors(startPos, endPos, k);
			controls.target.lerpVectors(startTarget, endTarget, k);
			controls.update();
			if (anim.current.t >= 1) anim.current.active = false;
		}
		controls.autoRotate = autoRotate && !anim.current.active;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
		ref: controlsRef,
		makeDefault: true,
		enableDamping: true,
		dampingFactor: .085,
		autoRotate,
		autoRotateSpeed: .55,
		minDistance: MIN_DIST,
		maxDistance: MAX_DIST,
		minPolarAngle: Math.PI * .2,
		maxPolarAngle: Math.PI * .58,
		enablePan: false,
		rotateSpeed: .68,
		zoomSpeed: .85,
		touches: {
			ONE: TOUCH.ROTATE,
			TWO: TOUCH.DOLLY_ROTATE
		}
	});
}
function StudioLights() {
	const preset = useStudio((s) => s.lightPreset);
	const keyIntensity = useStudio((s) => s.keyIntensity);
	const warmth = useStudio((s) => s.warmth);
	const envIntensity = useStudio((s) => s.envIntensity);
	const { scene, gl } = useThree();
	const keyColor = (0, import_react.useMemo)(() => new Color(), []);
	const fillColor = (0, import_react.useMemo)(() => new Color(), []);
	const rimColor = (0, import_react.useMemo)(() => new Color(), []);
	const coolKey = (0, import_react.useMemo)(() => new Color("#c9d4e4"), []);
	const warmKey = (0, import_react.useMemo)(() => new Color("#ffd6ae"), []);
	const coolFill = (0, import_react.useMemo)(() => new Color("#8ea0b8"), []);
	const warmFill = (0, import_react.useMemo)(() => new Color("#e7c3a4"), []);
	const coolRim = (0, import_react.useMemo)(() => new Color("#b7c4d4"), []);
	const warmRim = (0, import_react.useMemo)(() => new Color("#f0d2b4"), []);
	const warmthT = warmth / 100;
	keyColor.lerpColors(coolKey, warmKey, warmthT);
	fillColor.lerpColors(coolFill, warmFill, warmthT * .7);
	rimColor.lerpColors(coolRim, warmRim, warmthT * .45);
	const key = keyIntensity / 100 * (preset === "night" ? 2.1 : 1.55);
	const fill = keyIntensity / 100 * (preset === "gallery" ? .85 : .42);
	const rim = keyIntensity / 100 * (preset === "night" ? 1.6 : .7);
	const hemi = preset === "gallery" ? .38 : preset === "night" ? .08 : .16;
	const topGain = preset === "night" ? .45 : preset === "dawn" ? .8 : 1.15;
	const backGain = preset === "night" ? 1.6 : .9;
	const envKey = `${preset}-${Math.round(warmth / 8)}`;
	(0, import_react.useEffect)(() => {
		scene.environmentIntensity = envIntensity / 100 * 1.15;
		gl.toneMappingExposure = preset === "night" ? .84 : preset === "dawn" ? 1.12 : 1.06;
	}, [
		envIntensity,
		scene,
		gl,
		preset
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", {
			color: keyColor,
			groundColor: "#121110",
			intensity: hemi
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				3.2,
				3.4,
				2.2
			],
			intensity: key,
			color: keyColor
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-3.4,
				1.4,
				1.6
			],
			intensity: fill,
			color: fillColor
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("directionalLight", {
			position: [
				-.4,
				1.8,
				-3.4
			],
			intensity: rim,
			color: rimColor
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				.6,
				1.1,
				1.4
			],
			intensity: .22 * (keyIntensity / 100),
			color: keyColor,
			distance: 5
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Environment, {
			resolution: 256,
			frames: 1,
			environmentIntensity: envIntensity / 100 * 1.1,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
					form: "rect",
					intensity: 3.4 * topGain * (envIntensity / 100),
					position: [
						0,
						4.2,
						0
					],
					"rotation-x": Math.PI / 2,
					scale: [
						9,
						9,
						1
					],
					color: preset === "dawn" ? "#f3e0c8" : "#f2f2f4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
					form: "rect",
					intensity: 1.8 * (envIntensity / 100),
					position: [
						4.4,
						1.2,
						2.2
					],
					scale: [
						3.2,
						5,
						1
					],
					color: keyColor
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
					form: "rect",
					intensity: 1.1 * (envIntensity / 100),
					position: [
						-4.2,
						.6,
						1.6
					],
					scale: [
						2.6,
						5.4,
						1
					],
					color: fillColor
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
					form: "ring",
					intensity: 2.2 * backGain * (envIntensity / 100),
					position: [
						.2,
						1.4,
						-3.6
					],
					scale: 3.2,
					color: rimColor
				})
			]
		}, envKey)
	] });
}
function StudioFloor() {
	const resolution = useThree((s) => s.size.width) < 500 ? 128 : 256;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		rotation: [
			-Math.PI / 2,
			0,
			0
		],
		position: [
			0,
			-.55,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [7.5, 64] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeshReflectorMaterial, {
			blur: [280, 70],
			resolution,
			mixBlur: .85,
			mixStrength: 18,
			roughness: .9,
			metalness: .42,
			mirror: .12,
			color: "#101012"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		rotation: [
			-Math.PI / 2,
			0,
			0
		],
		position: [
			0,
			-.548,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
			.78,
			.92,
			64
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
			color: "#2c2c32",
			roughness: .22,
			metalness: .82,
			clearcoat: .35,
			clearcoatRoughness: .2
		})]
	})] });
}
function Scene() {
	const dismissHint = useStudio((s) => s.dismissHint);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioLights, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioFloor, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
			position: [
				0,
				-.547,
				0
			],
			opacity: .48,
			scale: 6.5,
			blur: 2.8,
			far: 1.6,
			color: "#000000"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				-.54,
				0
			],
			onPointerDown: dismissHint,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [6, 48] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				transparent: true,
				opacity: 0
			})]
		})
	] });
}
function ReadySignal() {
	(0, import_react.useEffect)(() => {
		useStudio.getState().setStudioReady(true);
	}, []);
	return null;
}
var ProductStudio = (0, import_react.memo)(function ProductStudio() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		className: "studio-canvas h-full w-full",
		camera: {
			position: [
				1.92,
				.7,
				2.4
			],
			fov: 30,
			near: .1,
			far: 40
		},
		dpr: [1, 1.75],
		gl: {
			antialias: true,
			alpha: true,
			powerPreference: "high-performance",
			toneMapping: 4,
			toneMappingExposure: 1.06
		},
		onCreated: ({ gl }) => {
			gl.setClearColor(0, 0);
			useStudio.getState().setStudioReady(true);
		},
		onPointerDown: () => useStudio.getState().dismissHint(),
		onDoubleClick: () => useStudio.getState().resetCamera(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadySignal, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})]
	});
});
function useMounted() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	return mounted;
}
function useDesktop() {
	const [desktop, setDesktop] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(min-width: 1024px)");
		const apply = () => setDesktop(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return desktop;
}
function StudioCanvas() {
	if (!useMounted()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full bg-background" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductStudio, {});
}
function ToolButton({ label, children, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "subtle",
			size: "icon",
			"aria-label": label,
			className: cn("shadow-[var(--shadow-border)]", className),
			...props,
			children
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		side: "left",
		children: label
	})] });
}
function Header() {
	const bagCount = useStudio((s) => s.bagCount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-4 p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in pointer-events-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl leading-none font-medium tracking-tight italic sm:text-4xl",
				children: "Aura"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs tracking-widest text-muted-foreground uppercase",
				children: "Studio"
			})]
		}), bagCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stagger-in pointer-events-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "rounded-full bg-card px-3 py-2 text-xs tabular-nums text-muted-foreground shadow-[var(--shadow-border)]",
				children: ["Bag ", bagCount]
			})
		}) : null]
	});
}
function ProductCopy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute top-24 left-4 z-30 max-w-56 sm:top-28 sm:left-6 sm:max-w-xs",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger-in",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-widest text-muted-foreground uppercase",
					children: "Aura One"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-2 text-3xl leading-none font-medium tracking-tight sm:text-5xl",
					children: "Quiet sound, sculpted."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 hidden text-sm leading-relaxed text-muted-foreground sm:block",
					children: "Over-ear wireless in five colorways. Drag to orbit, scroll to zoom."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 hidden text-xs tracking-wide text-subtle sm:block",
					children: "40 mm drivers · 40-hour charge · Adaptive quiet"
				})
			]
		})
	});
}
function VariantBar() {
	const colorway = useStudio((s) => s.colorway);
	const finish = useStudio((s) => s.finish);
	const setColorway = useStudio((s) => s.setColorway);
	const setFinish = useStudio((s) => s.setFinish);
	const addToBag = useStudio((s) => s.addToBag);
	const activeColor = getColorway(colorway);
	const activeFinish = getFinish(finish);
	const handleBag = () => {
		addToBag();
		toast.success("Added to bag", { description: `${activeColor.name} · ${activeFinish.name}` });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-0 z-30 p-4 sm:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto mx-auto flex max-w-5xl flex-col gap-3 rounded-2xl bg-card/80 p-3 shadow-[var(--shadow-float)] backdrop-blur-md sm:flex-row sm:items-end sm:gap-6 sm:p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Colorway"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [COLORWAYS.map((item) => {
							const selected = item.id === colorway;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-testid": `color-${item.id}`,
								"aria-label": item.name,
								"aria-pressed": selected,
								onClick: () => setColorway(item.id),
								className: cn("press-scale relative size-11 rounded-full", selected ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : "shadow-[var(--shadow-border)]"),
								style: { backgroundColor: item.body }
							}, item.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-sm text-foreground",
							children: activeColor.name
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Finish"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: FINISHES.map((item) => {
							const selected = item.id === finish;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-testid": `finish-${item.id}`,
								"aria-pressed": selected,
								onClick: () => setFinish(item.id),
								className: cn("press-scale h-11 rounded-lg px-3.5 text-sm font-medium", selected ? "bg-primary text-primary-foreground" : "bg-muted text-foreground hover:bg-muted/80"),
								children: item.name
							}, item.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4 sm:flex-col sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "In stock"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl leading-none tracking-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg text-muted-foreground",
								children: "$"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: "429"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						"data-testid": "add-to-bag",
						onClick: handleBag,
						className: "min-w-36 rounded-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {}), "Add to bag"]
					})]
				})
			]
		})
	});
}
function StudioDock() {
	const autoRotate = useStudio((s) => s.autoRotate);
	const setAutoRotate = useStudio((s) => s.setAutoRotate);
	const resetCamera = useStudio((s) => s.resetCamera);
	const nudgeZoom = useStudio((s) => s.nudgeZoom);
	const cycleView = useStudio((s) => s.cycleView);
	const viewId = useStudio((s) => s.viewId);
	const toggleLightsOpen = useStudio((s) => s.toggleLightsOpen);
	const lightsOpen = useStudio((s) => s.lightsOpen);
	const view = getView(viewId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute top-24 right-4 z-40 flex flex-col items-end gap-2 sm:top-28 sm:right-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex flex-col gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: "Reset camera",
					"data-testid": "reset-camera",
					onClick: resetCamera,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: `View: ${view.name}`,
					"data-testid": "cycle-view",
					onClick: cycleView,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: autoRotate ? "Stop auto-rotate" : "Auto-rotate",
					"data-testid": "auto-rotate",
					onClick: () => setAutoRotate(!autoRotate),
					"aria-pressed": autoRotate,
					children: autoRotate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: "Zoom in",
					"data-testid": "zoom-in",
					onClick: () => nudgeZoom(12),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: "Zoom out",
					"data-testid": "zoom-out",
					onClick: () => nudgeZoom(-12),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
					label: "Lighting",
					"data-testid": "toggle-lights",
					onClick: toggleLightsOpen,
					"aria-pressed": lightsOpen,
					className: cn("lg:hidden", lightsOpen && "bg-primary text-primary-foreground"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {})
				})
			]
		})
	});
}
function LightingPanel() {
	const mounted = useMounted();
	const desktop = useDesktop();
	const lightsOpen = useStudio((s) => s.lightsOpen);
	const preset = useStudio((s) => s.lightPreset);
	const setLightPreset = useStudio((s) => s.setLightPreset);
	const keyIntensity = useStudio((s) => s.keyIntensity);
	const warmth = useStudio((s) => s.warmth);
	const envIntensity = useStudio((s) => s.envIntensity);
	const setKeyIntensity = useStudio((s) => s.setKeyIntensity);
	const setWarmth = useStudio((s) => s.setWarmth);
	const setEnvIntensity = useStudio((s) => s.setEnvIntensity);
	const autoRotate = useStudio((s) => s.autoRotate);
	const setAutoRotate = useStudio((s) => s.setAutoRotate);
	if (!mounted || !desktop && !lightsOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		"data-open": lightsOpen || desktop,
		className: "chrome-motion pointer-events-auto absolute top-52 right-24 z-30 w-64 max-lg:top-auto max-lg:right-4 max-lg:bottom-40 max-lg:left-4 max-lg:w-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-card/85 p-3 shadow-[var(--shadow-float)] backdrop-blur-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Studio light"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Shape the room"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 text-muted-foreground" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-4 gap-1.5 lg:grid-cols-2",
					children: LIGHT_PRESETS.map((item) => {
						const selected = item.id === preset;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"data-testid": `preset-${item.id}`,
							"aria-pressed": selected,
							onClick: () => setLightPreset(item.id),
							className: cn("press-scale h-9 rounded-md text-sm font-medium", selected ? "bg-primary text-primary-foreground" : "bg-muted text-foreground hover:bg-muted/80"),
							children: item.name
						}, item.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-3" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Key light",
							value: keyIntensity,
							onValueChange: setKeyIntensity,
							className: "h-8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Warmth",
							value: warmth,
							onValueChange: setWarmth,
							className: "h-8"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Environment",
							value: envIntensity,
							onValueChange: setEnvIntensity,
							className: "h-8"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-9 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Auto-rotate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: autoRotate,
							onCheckedChange: setAutoRotate,
							"aria-label": "Auto-rotate"
						})]
					})]
				})
			]
		})
	});
}
function Hint() {
	const visible = useStudio((s) => s.hintVisible);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("chrome-motion pointer-events-none absolute bottom-44 left-1/2 z-20 -translate-x-1/2 text-center text-xs text-muted-foreground sm:bottom-40", visible ? "opacity-100" : "opacity-0"),
		children: "Drag to orbit · pinch or scroll to zoom"
	});
}
function LoadingVeil() {
	const ready = useStudio((s) => s.studioReady);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("chrome-motion pointer-events-none absolute inset-0 z-20 grid place-items-center bg-background", ready ? "opacity-0" : "opacity-100"),
		"aria-hidden": ready,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-4xl italic",
			children: "Aura"
		})
	});
}
function ProductViewer() {
	(0, import_react.useEffect)(() => {
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => {
			if (reduce.matches) useStudio.getState().setAutoRotate(false);
		};
		apply();
		reduce.addEventListener("change", apply);
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			const state = useStudio.getState();
			if (event.key === "r" || event.key === "R") state.resetCamera();
			if (event.key === " ") {
				event.preventDefault();
				state.setAutoRotate(!state.autoRotate);
			}
			if (event.key === "v" || event.key === "V") state.cycleView();
			if (event.key === "f" || event.key === "F") {
				const next = FINISHES[(FINISHES.findIndex((item) => item.id === state.finish) + 1) % FINISHES.length];
				if (next) state.setFinish(next.id);
			}
			if (event.key >= "1" && event.key <= "5") {
				const next = COLORWAYS[Number(event.key) - 1];
				if (next) state.setColorway(next.id);
			}
		};
		window.addEventListener("keydown", onKey);
		const hintTimer = window.setTimeout(() => {
			useStudio.getState().dismissHint();
		}, 5200);
		return () => {
			reduce.removeEventListener("change", apply);
			window.removeEventListener("keydown", onKey);
			window.clearTimeout(hintTimer);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh overflow-hidden bg-background text-foreground select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioCanvas, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "studio-vignette pointer-events-none absolute inset-0 z-10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingVeil, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCopy, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioDock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LightingPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VariantBar, {})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "dark",
		position: "top-center",
		toastOptions: { classNames: { toast: "bg-card text-foreground border-border" } }
	})] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductViewer, {});
}
//#endregion
export { Home as component };
