import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const svg = `file:///workspace/public/favicon.svg`;
const browser = await chromium.launch({ args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 64, height: 64 }, deviceScaleFactor: 1 });
await page.goto(svg);
await page.screenshot({ path: "/workspace/.grok/favicon-64.png", omitBackground: false });
await page.setViewportSize({ width: 16, height: 16 });
await page.goto(svg);
await page.screenshot({ path: "/workspace/.grok/favicon-16.png", omitBackground: false });
await browser.close();
console.log("wrote rasters");
